#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Finding: stackTop operation when top == -1, returns Shift Out character, with ASCII valuye 14
// arr[-1] is assigned 14 ASCII value when its memory is dinamically allocated
// and is assigned 00, i.e., NULL character, when memory is locally allocated

struct stack
{
    int size;
    int top;
    char *arr;
};

int isEmpty(struct stack *ptr)
{
    if (ptr->top == -1)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

int isFull(struct stack *ptr)
{
    if (ptr->top == ptr->size - 1)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

void push(struct stack *ptr, char val)
{
    if (isFull(ptr))
    {
        printf("Stack Overflow");
    }
    else
    {
        ptr->top++;
        ptr->arr[ptr->top] = val;
    }
}

char pop(struct stack *ptr)
{
    if (isEmpty(ptr))
    {
        printf("Stack Underflow");
        return -1;
    }
    else
    {
        char val = ptr->arr[ptr->top];
        ptr->top--;
        return val;
    }
}

char stackTop(struct stack * ptr){
    return ptr->arr[ptr->top];
}

char stackBottom(struct stack * ptr){
    return ptr -> arr[0];
}

// Reverse:
char * reverse(char * str){
    int n = strlen(str);
    char * rev = (char *)malloc((n + 1) * sizeof(char *));
    for(int i=0; i<n; i++){
        rev[i] = str[n-i-1];
    }
    rev[n] = '\0';
    return rev;
}
// Operator check
int isOperator(char ch){
    if(ch == '+' || ch == '-' || ch == '*' || ch == '/' || ch == '^' || ch == '%' || ch == '(' || ch == ')'){
        return 1;
    }
    else{
        return 0;
    }
}
// Precedence
int precedence(char ch){
    if(ch == '^' || ch == '%'){
        return 3;
    }
    else if(ch == '*' || ch == '/'){
        return 2;
    }
    else if(ch == '+' || ch == '-'){
        return 1;
    }
    else{
        return 0;
    }
}

//Infix to Postfix
char * infixtopostfix(char * infix){
    struct stack * sp = (struct stack *)malloc(sizeof(struct stack));
    sp->size = strlen(infix);
    sp->top = -1;
    sp->arr = (char *)malloc(sp->size * sizeof(char *));
    char * postfix = (char *)malloc((sp->size + 1) * sizeof(char *));
    int i = 0; // Infix Iterator
    int j = 0; // Postfix filler

    while(infix[i]!= '\0'){
        if(!isOperator(infix[i])){
            postfix[j] = infix[i];
            i++, j++;
        }
        else if(infix[i] == '('){
            push(sp, infix[i]);
            i++;
        }
        else if(infix[i] == ')'){
            while(stackTop(sp) != '('){
                postfix[j] = pop(sp);
                j++;
            }
            pop(sp);
            i++;
        }
        else{
            if(precedence(infix[i]) > precedence(stackTop(sp))){
                push(sp, infix[i]);
                i++;
            } 
            else{
                postfix[j] = pop(sp);
                j++;
            }
        }
    }

    while(!isEmpty(sp)){
        postfix[j] = pop(sp);
        j++;
    }
    postfix[j] = '\0';
    return postfix;
}

// Infix to Prefix:
char * infixtoprefix(char * infix){
    struct stack * sp = (struct stack *)malloc(sizeof(struct stack));
    sp->size = strlen(infix);
    sp->top = -1;
    sp->arr = (char *)malloc((sp->size + 1) * sizeof(char));
    char * prefix = (char *)malloc((sp->size + 1) * sizeof(char));
    int i = 0; // Infix reverse Iterator
    int j = 0; // Prefix filler

    char * rev = reverse(infix);

    while(rev[i] != '\0'){
        if(!isOperator(rev[i])){
            prefix[j] = rev[i];
            i++; j++;
        }
        else if(rev[i] == ')'){
            push(sp, rev[i]);
            i++;
        }
        else if(rev[i] == '('){
            while(stackTop(sp) != ')'){
                prefix[j] = pop(sp);
                j++;
            }
            pop(sp);
            i++;
        }
        else{
            if(precedence(rev[i]) >= precedence(stackTop(sp))){
                push(sp, rev[i]);
                i++;
            }
            else{
                prefix[j] = pop(sp);
                j++;
            }
        }
    }

    while(!isEmpty(sp)){
        prefix[j] = pop(sp);
        j++;
    }
    prefix[j] = '\0';
    prefix = reverse(prefix);
    return prefix;
}

char * postfixtoinfix(char * postfix){
    struct stack * sp = (struct stack *)malloc(sizeof(struct stack));
    sp->size = strlen(postfix);
    sp->top = -1;
    sp->arr = (char *)malloc(sp->size * sizeof(char *));
    char * prefix = (char *)malloc((sp->size+1) * sizeof(char *));
    int i = 0; // postfix
    int j = 0; // prefix
    while(postfix[i]!=0){
        if(!isOperator(postfix[i])){
            push(sp, postfix[i]);
            i++;
        }
        else{
            
        }
    }
}

int main()
{
    // char * infix = "(x+y-z)*y/s/d*a-c^b";
    char * infix = "a*b-c/d+e"; 
    // char * infix = "(a+b/c*(d+c)-f)"; 
    // char * infix = "(m-n)*(p+q)"; 
    // printf("%d  \n", strlen(infix));
    // char * infix = "k+l-m*n+(o^p)*w/u/v*t+q";
    printf("Postfix of Expression %s is: %s\n", infix, infixtopostfix(infix));
    printf("Prefix of Expression %s is: %s\n", infix, infixtoprefix(infix));
    printf("reverse: %s\n", reverse(infix) );
    
    return 0;
}
