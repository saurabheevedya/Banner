#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Student structure
struct Student {
    char name[50];
    int rollNo;
    float marks;
};

// Function to swap two students
void swap(struct Student *a, struct Student *b) {
    struct Student temp = *a;
    *a = *b;
    *b = temp;
}

// Function to perform Selection Sort
int selectionSort(struct Student arr[], int n) {
    int i, j, minIndex, swapCount = 0;
    for (i = 0; i < n - 1; i++) {
        minIndex = i;
        for (j = i + 1; j < n; j++) {
            if (arr[j].rollNo < arr[minIndex].rollNo) {
                minIndex = j;
            }
        }
        if (minIndex != i) {
            swap(&arr[i], &arr[minIndex]);
            swapCount++;
        }
    }
    return swapCount;
}

// Function to perform Merge Sort
void merge(struct Student arr[], int l, int m, int r, int *swapCount) {
    int i, j, k;
    int n1 = m - l + 1;
    int n2 = r - m;

    // Create temporary arrays
    struct Student L[n1], R[n2];

    // Copy data to temporary arrays
    for (i = 0; i < n1; i++) {
        L[i] = arr[l + i];
    }
    for (j = 0; j < n2; j++) {
        R[j] = arr[m + 1 + j];
    }

    // Merge the temporary arrays back into arr[l..r]
    i = 0;
    j = 0;
    k = l;
    while (i < n1 && j < n2) {
        if (L[i].rollNo <= R[j].rollNo) {
            arr[k] = L[i];
            i++;
        } else {
            arr[k] = R[j];
            j++;
            (*swapCount)++;
        }
        k++;
    }

    // Copy the remaining elements of L[], if there are any
    while (i < n1) {
        arr[k] = L[i];
        i++;
        k++;
    }

    // Copy the remaining elements of R[], if there are any
    while (j < n2) {
        arr[k] = R[j];
        j++;
        k++;
    }
}

void mergeSort(struct Student arr[], int l, int r, int *swapCount) {
    if (l < r) {
        int m = l + (r - l) / 2;
        mergeSort(arr, l, m, swapCount);
        mergeSort(arr, m + 1, r, swapCount);
        merge(arr, l, m, r, swapCount);
    }
}

// Main function
int main() {
    int n;
    printf("Enter the number of students: ");
    scanf("%d", &n);

    struct Student arr[n];

    // Input the student details
    for (int i = 0; i < n; i++) {
        printf("\nEnter details of student %d:\n", i + 1);
        printf("Name: ");
        scanf("%s", arr[i].name);
        printf("Roll No: ");
        scanf("%d", &arr[i].roll_no);
        printf("Marks: ");
        scanf("%d", &arr[i].marks);
    }

    int selection_swap_count = 0;
    int merge_swap_count = 0;

    struct Student selection_sorted_arr[n];
    struct Student merge_sorted_arr[n];
    memcpy(selection_sorted_arr, arr, sizeof(arr));
    memcpy(merge_sorted_arr, arr, sizeof(arr));

    // Perform selection sort
    selection_sort(selection_sorted_arr, n, &selection_swap_count);

    // Perform merge sort
    merge_sort(merge_sorted_arr, 0, n - 1, &merge_swap_count);

    // Print the sorted arrays and number of swaps performed
    printf("\nSelection sort:\n");
    printf("Sorted array (by roll no):\n");
    for (int i = 0; i < n; i++) {
        printf("Name: %s, Roll No: %d, Marks: %d\n", selection_sorted_arr[i].name,
               selection_sorted_arr[i].roll_no, selection_sorted_arr[i].marks);
    }
    printf("Number of swaps: %d\n", selection_swap_count);

    printf("\nMerge sort:\n");
    printf("Sorted array (by roll no):\n");
    for (int i = 0; i < n; i++) {
        printf("Name: %s, Roll No: %d, Marks: %d\n", merge_sorted_arr[i].name,
               merge_sorted_arr[i].roll_no, merge_sorted_arr[i].marks);
    }
    printf("Number of swaps: %d\n", merge_swap_count);

    return 0;
}