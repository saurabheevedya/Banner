#include <stdio.h>
#include <stdlib.h>

struct Node{
    int data;
    struct Node * next;
};

void linkedlisttravesal(struct Node* ptr){
    while(ptr!=NULL){
        printf("Element: %d \n", ptr->data);
        ptr = ptr->next;
    }
}

// Case 1: Delete first Node
struct Node * delFirstNode(struct Node * head){
    struct Node * ptr = head;
    head = head->next;
    free(ptr);
    return head;
}

// Case 2: Delete Node at specific index
struct Node * delAtIndex(struct Node * head, int index){
    struct Node * p = head;
    for(int i=1; i<index-1; i++){
        p = p->next;
    }
    struct Node * ptr = p->next;
    p->next = ptr->next;
    free(ptr);
    return head;
}

// Case 3: Delete Last Node
struct Node * delLastNode(struct Node * head){
    struct Node * p = head;
    while((p->next)->next  !=NULL){
        p = p->next;
    }
    struct Node * ptr = p->next;
    p->next=NULL;
    free(ptr);
    return head;
}

//Case 4: Delete first Node with a given value/data
struct Node * delOfValue(struct Node * head, int data){
    struct Node * p = head;
    if(p->data == data){
        struct Node * ptr = head;
        head = head->next;
        free(ptr);
        return head;
    }
    for(int i = 1; p->next!=NULL; i++){
        if((p->next)->data == data){
            struct Node * ptr = p->next;
            p->next = ptr->next;
            free(ptr);
            return head;
        }
        p = p->next;
    }
    return head;
}


int main(){
    struct Node * head = (struct Node* ) malloc (sizeof(struct Node));
    struct Node * second = (struct Node* ) malloc (sizeof(struct Node));
    struct Node * third = (struct Node* ) malloc (sizeof(struct Node));
    struct Node * fourth = (struct Node* ) malloc (sizeof(struct Node));

    head->data = 10;
    head->next = second;

    second->data = 20;
    second->next = third;
    
    third->data = 30;
    third->next = fourth;

    fourth->data = 40;
    fourth->next = NULL;

    printf("Before Insertion:\n");
    linkedlisttravesal(head);
    printf("\n");

    // head = delFirstNode(head);
    // head = delAtIndex(head, 3);
    // head = delLastNode(head);
    head = delOfValue(head, 30);


    printf("After deletion:\n");
    linkedlisttravesal(head);
    printf("\n");


}


