#include <stdio.h>
#include <stdlib.h>

struct Node{
    struct Node * prev;
    int data;
    struct Node * next;
};

void linkedlisttravesal(struct Node* head){
    struct Node * p = head;
    while(p != NULL){
        printf("Element: %d \n", p->data);
        p = p->next;
    }
}

void linkedlisttravesal_Reverse(struct Node* head){
    struct Node * p = head;
    while(p->next != NULL){
        p = p->next;
    }
    while(p != NULL){
        printf("Element: %d \n", p->data);
        p = p->prev;
    }
}

struct Node * merge(struct Node * head1, struct Node * head2){
    struct Node * h1 = head1;
    struct Node * h2 = head2;
    struct Node * p = (struct Node* ) malloc (sizeof(struct Node));
    struct Node * head_of_merged_list = p;
    p->prev = NULL;

    if(h1->data == h2->data){
        p->data = h1->data;

        struct Node * pt = (struct Node* ) malloc (sizeof(struct Node));
        pt->data = h2->data;
        pt->next = NULL;
        p->next = pt;
        pt->prev = p;
        p = p->next;

        h1 = h1->next;
        h2 = h2->next;
    }
    else if(h1->data < h2->data){
        p->data = h1->data;
        p->next = NULL;
        h1 = h1->next;
    }
    else{
        p->data = h2->data;
        p->next = NULL;
        h2 = h2->next;
    }

    while(h1 != NULL && h2 != NULL){
        if(h1->data == h2->data){
            // p->next->data = h1->data;
            struct Node * pt1 = (struct Node* ) malloc (sizeof(struct Node));
            pt1->data = h1->data;
            p->next = pt1;
            pt1->prev = p;
            p = p->next;

            struct Node * pt2 = (struct Node* ) malloc (sizeof(struct Node));
            pt2->data = h2->data;
            pt2->next = NULL;
            p->next = pt2;
            pt2->prev = p;
            p = p->next;
            
            h1 = h1->next;
            h2 = h2->next;
        }
        else if(h1->data < h2->data){
            struct Node * pt = (struct Node* ) malloc (sizeof(struct Node));
            pt->data = h1->data;
            pt->next = NULL;
            p->next = pt;
            pt->prev = p;
            p = p->next;

            h1 = h1->next;
        }
        else{
            struct Node * pt = (struct Node* ) malloc (sizeof(struct Node));
            pt->data = h2->data;
            pt->next = NULL;
            p->next = pt;
            pt->prev = p;
            p = p->next;

            h2 = h2->next;
        }
    }

    while(h1 != NULL){
        struct Node * pt = (struct Node* ) malloc (sizeof(struct Node));
        pt->data = h1->data;
        pt->next = NULL;
        p->next = pt;
        pt->prev = p;
        p = p->next;

        h1 = h1->next;
    }
    while(h2 != NULL){
        struct Node * pt = (struct Node* ) malloc (sizeof(struct Node));
        pt->data = h2->data;
        pt->next = NULL;
        p->next = pt;
        pt->prev = p;
        p = p->next;

        h2 = h2->next;
    }
    return head_of_merged_list;
}


int main(){
    struct Node * head = (struct Node* ) malloc (sizeof(struct Node));
    struct Node * second = (struct Node* ) malloc (sizeof(struct Node));
    struct Node * third = (struct Node* ) malloc (sizeof(struct Node));
    struct Node * fourth = (struct Node* ) malloc (sizeof(struct Node));

    head->prev = NULL;
    head->data = 10;
    head->next = second;

    second->prev = head;
    second->data = 20;
    second->next = third;

    third->prev = second; 
    third->data = 30;
    third->next = fourth;

    fourth->prev = third;
    fourth->data = 40;
    fourth->next = NULL;

    struct Node * head2 = (struct Node* ) malloc (sizeof(struct Node));
    struct Node * second2 = (struct Node* ) malloc (sizeof(struct Node));
    struct Node * third2 = (struct Node* ) malloc (sizeof(struct Node));
    struct Node * fourth2 = (struct Node* ) malloc (sizeof(struct Node));

    head2->prev = NULL;
    head2->data = 10;
    head2->next = second2;

    second2->prev = head2;
    second2->data = 25;
    second2->next = third2;

    third2->prev = second2; 
    third2->data = 35;
    third2->next = fourth2;

    fourth2->prev = third2;
    fourth2->data = 40;
    fourth2->next = NULL;

    printf("DLL traversal of DLL 1:\n");
    linkedlisttravesal(head);
    printf("\n");
    printf("DLL traversal in reverse order:\n");
    linkedlisttravesal_Reverse(head);
    printf("\n");

    printf("DLL traversal of DLL 2:\n");
    linkedlisttravesal(head2);
    printf("\n");
    printf("DLL traversal in reverse order:\n");
    linkedlisttravesal_Reverse(head2);
    printf("\n");

    struct Node * merged_head = merge(head, head2);

    printf("DLL traversal:\n");
    linkedlisttravesal(merged_head);
    printf("\n");
    printf("DLL traversal in reverse order:\n");
    linkedlisttravesal_Reverse(merged_head);
    printf("\n");

}