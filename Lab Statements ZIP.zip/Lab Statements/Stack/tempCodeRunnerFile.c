
    char * constr = "Harsh)";
    strcat(arr2, constr);