#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#define MAX_VERTICES 50

// A structure to represent an adjacency list node
struct AdjListNode{
    int dest;
    int wt;
    struct AdjListNode * next;
};

// A structure to represent an adjacency list
struct AdjList{
    struct AdjListNode * head;
};

// A structure to represent a graph. A graph
// is an array of adjacency lists.
// Size of array will be V (number of vertices
// in graph)
struct Graph{
    int V;
    struct AdjList * array;
};

struct AdjListNode * newAdjListNode(int dest, int wt){
    struct AdjListNode * newNode = (struct AdjListNode *)malloc(sizeof(struct AdjListNode));
    newNode->dest = dest;
    newNode->wt = wt;
    newNode->next = NULL;
    return newNode;
}

struct Graph * createGraph(int V){
    struct Graph * graph = (struct Graph *)malloc(sizeof(struct Graph));
    graph->V = V;
    // Create an array of adjacency lists.  Size of
    // array will be V
    graph->array = (struct AdjList *)malloc(V * sizeof(struct AdjList));
    for(int i=0; i<V; i++){
        graph->array[i].head = NULL;
    }
    return graph;
}

void addEdge(struct Graph * graph, int src, int dest, int wt){
    struct AdjListNode * check = NULL;
    struct AdjListNode * newNode = newAdjListNode(dest, wt);

    // Add an edge from src to dest.  A new node is
    // added to the adjacency list of src.  The node
    // is added at the beginning
    if(graph->array[src].head == NULL){
        graph->array[src].head = newNode;
    }
    else{
        check = graph->array[src].head;
        while(check->next != NULL){
            check = check->next;
        }
        check->next = newNode;
    }

    // Since graph is undirected, add an edge from
    // dest to src also
    newNode = newAdjListNode(src, wt);
    if(graph->array[dest].head == NULL){
        graph->array[dest].head = newNode;
    }
    else{
        check = graph->array[dest].head;
        while(check->next != NULL){
            check = check->next;
        }
        check->next = newNode;
    }
}

void printGraph(struct Graph * graph){
    for(int i=0; i<graph->V; i++){
        struct AdjListNode * node = graph->array[i].head;
        printf("Adjacency List of vertex %d ", i);
        while(node){
            printf("-> %d ", node->dest);
            node = node->next;
        }
        printf("\n");
    }
}

// Finding Minimum Weight Vertex
int minimumVertex(int value[], bool visited[], int V){
	int minimum = INT_MAX;
	int vertex;
	for(int i=0; i<V; i++){
		if(visited[i] == false && value[i] < minimum){
			vertex = i;
			minimum = value[i];
		}
	}
	return vertex;
}

void PrimsMST(struct Graph * graph, int V){
    int value[V];
	bool visited[V];
	int parent[V];
	for(int i=0; i<V; i++){
		value[i] = INT_MAX;
		visited[i] = false;
	}
	value[0] = 0;
	parent[0] = -1;

	for(int i=0; i<V-1; i++){
		//Select best Vertex by applying greedy method
		int U = minimumVertex(value, visited, V);
		visited[U] = true;//Include new Vertex in MST

        struct AdjListNode * head = graph->array[U].head;

        while(head){
            if(visited[head->dest] == false && head->wt < value[head->dest]){
                value[head->dest] = head->wt;
                parent[head->dest] = U;
            }
            head = head->next;
        }

		// for(int j=0; j<V; j++){
		// 	/* 3 constraints to relax:-
		// 	      1.Edge is present from U to j.
		// 	      2.Vertex j is not included in MST
		// 	      3.Edge weight is smaller than current edge weight
		// 	*/
		// 	if(graph[U][j]!=0 && visited[j]==false && graph[U][j] < value[j] ){
		// 		value[j] = graph[U][j];
		// 		parent[j] = U;
		// 	}
		// }
	}
	//Print MST
	for(int i=1; i<V; i++){
		printf("U -> V: %d -> %d; wt = %d\n", parent[i], i, value[i]);
	}
}

int main(){
    int V = 6;
    struct Graph * g = createGraph(V);
    addEdge(g, 0, 1, 4);
    addEdge(g, 0, 2, 6);
    addEdge(g, 1, 2, 6);
    addEdge(g, 1, 3, 3);
    addEdge(g, 1, 4, 4);
    addEdge(g, 2, 3, 1);
    addEdge(g, 3, 4, 2);
    addEdge(g, 3, 5, 3);
    addEdge(g, 4, 5, 7);
    // print adjacency list:
    printGraph(g);

    PrimsMST(g, V);
    return 0;
}

