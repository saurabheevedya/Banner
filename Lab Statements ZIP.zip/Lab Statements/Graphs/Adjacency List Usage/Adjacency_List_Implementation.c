#include <stdio.h>
#include <stdlib.h>

//In the given code, graph->array is a pointer to an array of AdjList structures. Each AdjList structure has a member named head which is a pointer to the first node of the linked list. So, when we initialize each adjacency list as empty, we make the head pointer NULL, which indicates that there are no nodes in the linked list.

//If we initialize graph->array[i] to NULL, we will lose the pointer to the head of the linked list, which will result in a segmentation fault when we try to add nodes to the linked list. This is because we will be dereferencing a null pointer when we try to access graph->array[i].head in addEdge function.

//Hence, it is necessary to initialize graph->array[i].head to NULL in order to create an empty linked list for each vertex of the graph.

// A structure to represent an adjacency list node
struct AdjListNode{
    int dest;
    struct AdjListNode * next;
};

// A structure to represent an adjacency list
struct AdjList{
    struct AdjListNode * head;
};

// A structure to represent a graph. A graph
// is an array of adjacency lists.
// Size of array will be V (number of vertices
// in graph)
struct Graph{
    int V;
    struct AdjList * array;
};

struct AdjListNode * newAdjListNode(int dest){
    struct AdjListNode * newNode = (struct AdjListNode *)malloc(sizeof(struct AdjListNode));
    newNode->dest = dest;
    newNode->next = NULL;
    return newNode;
}

struct Graph * createGraph(int V){
    struct Graph * graph = (struct Graph *)malloc(sizeof(struct Graph));
    graph->V = V;
    // Create an array of adjacency lists.  Size of
    // array will be V
    graph->array = (struct AdjList *)malloc(V * sizeof(struct AdjList));
    for(int i=0; i<V; i++){
        graph->array[i].head = NULL;
    }
    return graph;
}

void addEdge(struct Graph * graph, int src, int dest){
    struct AdjListNode * check = NULL;
    struct AdjListNode * newNode = newAdjListNode(dest);

    // Add an edge from src to dest.  A new node is
    // added to the adjacency list of src.  The node
    // is added at the beginning
    if(graph->array[src].head == NULL){
        graph->array[src].head = newNode;
    }
    else{
        check = graph->array[src].head;
        while(check->next != NULL){
            check = check->next;
        }
        check->next = newNode;
    }

    // Since graph is undirected, add an edge from
    // dest to src also
    newNode = newAdjListNode(src);
    if(graph->array[dest].head == NULL){
        graph->array[dest].head = newNode;
    }
    else{
        check = graph->array[dest].head;
        while(check->next != NULL){
            check = check->next;
        }
        check->next = newNode;
    }
}

void printGraph(struct Graph * graph){
    for(int i=0; i<graph->V; i++){
        struct AdjListNode * node = graph->array[i].head;
        printf("Adjacency List of vertex %d ", i);
        while(node){
            printf("-> %d ", node->dest);
            node = node->next;
        }
        printf("\n");
    }
}

int main(){
    int V = 5;
    struct Graph * graph = createGraph(V);
    addEdge(graph, 0, 1);
    addEdge(graph, 0, 4);
    addEdge(graph, 1, 2);
    addEdge(graph, 1, 3);
    addEdge(graph, 1, 4);
    addEdge(graph, 2, 3);
    addEdge(graph, 3, 4);
    // print adjacency list:
    printGraph(graph);
    return 0;
}