#include <stdio.h>
#include <limits.h>

#define V 5
int parent[V];

int find(int n){
    if(parent[n] == n){
        return n;
    }
    return find(parent[n]);
}

void union_op(int i, int j){
    int src = find(i);
    int dst = find(j);
    parent[src] = dst;
}

// Find set of vertex i
void kruskalMST(int cost[][V]){
    int mincost = 0;
    for(int i=0; i<V; i++){
        parent[i] = i;
    }
    int edge_count = 0;
    while(edge_count < V-1){
        int min = INT_MAX, a = -1, b = -1; 
        for(int i=0; i<V; i++){
            for(int j=0; j<V; j++){
                if(find(i) != find(j) && cost[i][j] < min){
                    min = cost[i][j];
                    a = i;
                    b = j;
                }
            }
        }
        union_op(a, b);
        printf("Edge %d: (%d, %d) cost:%d \n", edge_count++, a, b, min);
        mincost += min;
    }
    printf("Minimum cost: %d\n", mincost);
}

int main(){
    /* Let us create the following graph
          2    3
      (0)--(1)--(2)
       |   / \   |
      6| 8/   \5 |7
       | /     \ |
      (3)-------(4)
            9          */
    int cost[][V] = {
        { INT_MAX, 2, INT_MAX, 6, INT_MAX },
        { 2, INT_MAX, 3, 8, 5 },
        { INT_MAX, 3, INT_MAX, INT_MAX, 7 },
        { 6, 8, INT_MAX, INT_MAX, 9 },
        { INT_MAX, 5, 7, 9, INT_MAX },
    };

    kruskalMST(cost);
 
    return 0;
}

