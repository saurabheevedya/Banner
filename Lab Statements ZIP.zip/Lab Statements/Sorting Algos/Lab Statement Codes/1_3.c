#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_EMPLOYEES 100

typedef struct Employee {
    char employee_name[50];
    int emp_no;
    float emp_salary;
} Employee;

void selectionSort(Employee arr[], int n, int *swap_count) {
    int i, j, min_idx;
    Employee temp;

    for (i = 0; i < n - 1; i++) {
        min_idx = i;
        for (j = i + 1; j < n; j++) {
            if (arr[j].emp_no < arr[min_idx].emp_no) {
                min_idx = j;
            }
        }
        if (min_idx != i) {
            temp = arr[i];
            arr[i] = arr[min_idx];
            arr[min_idx] = temp;
            (*swap_count)++;
        }
    }
}

void bucketSort(Employee arr[], int n, int *swap_count) {
    int i, j;
    Employee bucket[MAX_EMPLOYEES];
    Employee *p_bucket[MAX_EMPLOYEES];
    int bucket_size[MAX_EMPLOYEES] = {0};

    for (i = 0; i < n; i++) {
        int bucket_idx = arr[i].emp_no / 10;
        bucket[bucket_idx] = arr[i];
        p_bucket[bucket_idx] = &bucket[bucket_idx];
        bucket_size[bucket_idx]++;
    }

    int k = 0;
    for (i = 0; i < MAX_EMPLOYEES; i++) {
        if (bucket_size[i] > 0) {
            selectionSort(p_bucket[i], bucket_size[i], swap_count);
            for (j = 0; j < bucket_size[i]; j++) {
                arr[k++] = *p_bucket[i]++;
            }
        }
    }
}

int main() {
    int n, i, swap_count = 0;
    Employee arr[MAX_EMPLOYEES];

    printf("Enter the number of employees: ");
    scanf("%d", &n);

    printf("Enter employee details (name, emp_no, emp_salary):\n");
    for (i = 0; i < n; i++) {
        scanf("%s %d %f", arr[i].employee_name, &arr[i].emp_no, &arr[i].emp_salary);
    }

    printf("\nBefore sorting:\n");
    printf("Employee Name\tEmployee No.\tEmployee Salary\n");
    for (i = 0; i < n; i++) {
        printf("%s\t\t%d\t\t%.2f\n", arr[i].employee_name, arr[i].emp_no, arr[i].emp_salary);
    }

    bucketSort(arr, n, &swap_count);

    printf("\nAfter sorting:\n");
    printf("Employee Name\tEmployee No.\tEmployee Salary\n");
    for (i = 0; i < n; i++) {
        printf("%s\t\t%d\t\t%.2f\n", arr[i].employee_name, arr[i].emp_no, arr[i].emp_salary);
    }

    printf("\nNumber of swaps performed: %d\n", swap_count);

    return 0;
}