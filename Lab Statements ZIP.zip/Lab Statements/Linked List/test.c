#include <stdio.h>
#include <stdbool.h>



int main(){
    bool ab = true;
    printf("%d", ab);
}