#include <stdio.h>
#include <malloc.h>
#define COUNT 5

struct Node{
    int data;
    struct Node * left;
    struct Node * right;
};

// <-- STACK OPERATIONS 
struct stack
{
    int size;
    int top;
    struct Node* *ndarr;
};

struct stack * createstack(int capacity){
    struct stack * st = (struct stack *)malloc(sizeof(struct stack));
    st->top = -1;
    st->size = capacity;
    st->ndarr = (struct Node **)malloc(st->size * sizeof(struct Node *));
    return st;
}

int isEmpty(struct stack * ptr){
    if(ptr->top == -1){
        return 1;
    }
    else{
        return 0;
    }
}

int isFull(struct stack * ptr){
    if(ptr->top == ptr->top-1){
        return 1;
    }
    else{
        return 0;
    }
}

void push(struct stack *ptr, struct Node * node){
    if(isFull(ptr)){
        printf("Stack Overflow");
    }
    else{
        ptr->top++;
        ptr->ndarr[ptr->top] = node;
    }
}

struct Node* pop(struct stack * ptr){
    if(isEmpty(ptr)){
        printf("Stack Underflow");
        return NULL;
    }
    else{
        struct Node * node = ptr->ndarr[ptr->top];
        ptr->top--;
        return node;
    }
}

struct Node * peek(struct stack * ptr, int i){
    int index = ptr->top - i + 1;
    if(index < 0){
        printf("Index out of Bounds\n");
        return NULL;
    }
    else{
        return ptr->ndarr[index];
    }
}

struct Node * stackTop(struct stack * ptr){
    return ptr->ndarr[ptr->top];
}

struct Node * stackBottom(struct stack * ptr){
    return ptr -> ndarr[0];
}
// STACK OPERATIONS -->

struct Node * createNode(int data){
    struct Node * p = (struct Node *)malloc(sizeof(struct Node)); // creating a node pointer and Allocating memory in the heap
    p->data = data; // Setting the data
    p->left = NULL; // Setting the left and right children to NULL
    p->right = NULL; 
    return p;
}

void preorder(struct Node * root){
    if(root!=NULL){
        printf("%d ", root->data);
        preorder(root->left);
        preorder(root->right);
    }
}

void postorder(struct Node * root){
    if(root!=NULL){
        postorder(root->left);
        postorder(root->right);
        printf("%d ", root->data);
    }
}

void inorder(struct Node * root){
    if(root!=NULL){
        inorder(root->left);
        printf("%d ", root->data);
        inorder(root->right);
    }
}

void preorder_stack(struct Node * p, int height){
    struct stack * st = createstack(height+1);
    while(1){
        while(p){
            printf("%d ", p->data);
            push(st, p);
            p = p->left;
        }
        if(isEmpty(st)){
            break;
        }
        p = pop(st);
        p = p->right;
    }
    printf("\n");
}

void inorder_stack(struct Node * p, int height){
    struct stack * st = createstack(height + 1);
    while(1){
        while(p){
            push(st, p);
            p = p->left;
        }
        if(isEmpty(st)){
            break;
        }
        p = pop(st);
        printf("%d ", p->data);
        p = p->right;
    }
    printf("\n");
}


// Postorder using 2 stacks:
void postorder_stack2(struct Node * p, int height){
    if(p == NULL){
        return;
    }
    struct stack * st1 = createstack(height+1);
    struct stack * st2 = createstack(height+1);
    push(st1, p);
    while(!isEmpty(st1)){
        p = pop(st1);
        push(st2, p);
        if(p->left != NULL){
            push(st1, p->left);
        }
        if(p->right != NULL){
            push(st1, p->right);
        }
    }
    while(!isEmpty(st2)){
        p = pop(st2);
        printf("%d ", p->data);
    }printf("\nhii\n");
}

// Postorder using 1 stack:
void postorder_onestack(struct Node * pt, int height){
    struct stack * stk = createstack(height+1);
    struct Node * cur = pt;
    // struct Node * temp = createNode(0);
    while(!isEmpty(stk) || cur != NULL){
        if(cur != NULL){
            push(stk, cur);
            cur = cur->left;
        }
        else{
            struct Node * temp = stackTop(stk)->right;
            if(temp == NULL){
                temp = pop(stk);
                printf("%d ", temp->data);
                while(!isEmpty(stk) && temp == stackTop(stk)->right){
                    temp = pop(stk);
                    printf("%d ", temp->data);
                }
            }
            else{
                cur = temp;
            }
        }
    }
    printf("\n");
}


// count recursively:
int totalNodes(struct Node * root){
    if (root == NULL)
        return 0;

    int l = totalNodes(root->left);
    int r = totalNodes(root->right);
 
    return 1 + l + r;
}

// Height of Tree using recursion:
int height(struct Node *p)
{
    int leftht, rightht;
    if (p == NULL)
    {
        return 0;
    }
    else
    {
        leftht = height(p->left);
        rightht = height(p->right);
        if (leftht > rightht)
        {
            return leftht + 1;
        }
        else
        {
            return rightht + 1;
        }
    }
}

// Level wise display using recursion:
void levelNode(struct Node *p, int level)
{
    if (p != NULL)
    {
        if (level == 1)
        {
            printf("%d\t", p->data);
        }
        else if (level > 1)
        {
            levelNode(p->left, (level - 1));
            levelNode(p->right, (level - 1));
        }
    }
}

// mirrorify using recursion:
void mirrorimage(struct Node *p)
{
    struct node *temp;
    if (p != NULL)
    {
        mirrorimage(p->left);
        mirrorimage(p->right);
        temp = p->left;
        p->left = p->right;
        p->right = temp;
       
    }
}

// Find Operation:
struct Node * find(struct Node * root, int id){
    struct Node * temp = root;
    while(temp != NULL){
        if(id < temp->data){
            temp = temp->left;
            continue;
        }
        else if(id > temp->data){
            temp = temp->right;
            continue;
        }
        if(id == temp->data){
            return temp;
        }
    }
    printf("Id not found\n");
    return NULL;
}

//  Code for printing the BST using recursion:

// It does reverse inorder traversal
void print2DUtil(struct Node* root, int space)
{
    // Base case
    if (root == NULL)
        return;
 
    // Increase distance between levels
    space += COUNT;
 
    // Process right child first
    print2DUtil(root->right, space);
 
    // Print current node after space
    // count
    // printf("\n");
    for (int i = COUNT; i < space; i++)
        printf(" ");
    printf("%d\n", root->data);
 
    // Process left child
    print2DUtil(root->left, space);
}
 
// Wrapper over print2DUtil()
void print2D(struct Node* root)
{
    // Pass initial space count as 0
    print2DUtil(root, 0);
}

// Maximum Value Node:
int maxValue(struct Node* node)
{  
    /* loop down to find the rightmost leaf */
    struct Node* current = node;
    while (current->right != NULL)
        current = current->right;
     
    return (current->data);
}

// Insert Operation
struct Node * insert(struct Node * root, int key){
    struct Node * ptr = createNode(key); 
    if(root == NULL){
        root = ptr;
        root->left = NULL;
        root->right = NULL;
        return root;
    }
    struct Node * temp = root;
    while(temp != NULL){
        if(key < temp->data){
            if(temp->left == NULL){
                temp->left = ptr;
                return root;
            }
            else{
                temp = temp->left;
            }
        }
        else if(key > temp->data){
            if(temp->right == NULL){
                temp->right = ptr;
                return root;
            }
            else{
                temp = temp->right;
            }
        }
        else if(key == temp->data){
            printf("The record is already present in Tree \n");
            return root;
        }
    }
    
}

struct Node * inOrderPredecessor(struct Node * root){
    root = root->left;
    while(root->right != NULL){
        root = root->right;
    }
    return root;
}

// Deletion
struct Node * deleteNode(struct Node * root, int value){
    struct Node * iPre;
    // Returning if Leaf Node found, or NULL found
    if(root == NULL){
        printf("The data to delete is not found\n");
        return NULL;
    }
    // checking for leaf node, freeing it and returning NULL as its replacement
    if(root->left == NULL && root->right == NULL && value == root->data){ // additional 3rd condition for checking if the required node is present or not
        free(root);
        return NULL;
    }

    // Search for the node to be deleted
    if(value < root->data){
        root->left = deleteNode(root->left, value);
    }
    else if(value > root->data){
        root->right = deleteNode(root->right, value);
    }
    else if(value == root->data){
        // This else part of delete function will run only whenever there is a need to find inorder predecessor
        // As when the leaf Node is found
        // NULL is returned in that case in above part of code
        iPre = inOrderPredecessor(root);
        root->data = iPre->data;
        root->left = deleteNode(root->left, iPre->data);
    }
    return root;
}

int main(){
    struct Node * p = (struct Node *)malloc(sizeof(struct Node));
    p = NULL;
    p = insert(p, 10);
    p = insert(p, 5);
    p = insert(p, 15);
    p = insert(p, 3);
    p = insert(p, 9);
    p = insert(p, 17);
    p = insert(p, 1);
    p = insert(p, 4);
    // Finally The tree looks like this:
    //                10
    //               /  \
    //              5   15   
    //             / \     \
    //            3    9    17
    //           / \
    //          1   4

    struct Node * pSecond = (struct Node *)malloc(sizeof(struct Node));
    pSecond = NULL;
    pSecond = insert(pSecond, 10);
    pSecond = insert(pSecond, 6);
    pSecond = insert(pSecond, 15);
    pSecond = insert(pSecond, 4);
    pSecond = insert(pSecond, 9);
    pSecond = insert(pSecond, 17);
    pSecond = insert(pSecond, 2);
    pSecond = insert(pSecond, 1);
    pSecond = insert(pSecond, 3);
    // Finally The tree looks like this:
    //                10
    //               /  \
    //              6   15   
    //             / \     \
    //            4   9    17
    //           / 
    //          2
    //         / \
    //        1   3

    printf("Inorder traversal: \n");
    inorder(p);
    printf("\n");   
    printf("Height of tree 1: %d\n", height(p) - 1);

    // Checking Deletion:
    int val = 10;
    printf("Deleting %d\n", val);
    deleteNode(p, val);
    printf("Inorder traversal: \n");
    inorder(p);
    printf("\n");    


    printf("Inorder traversal: \n");
    inorder(pSecond);
    printf("\n"); 
    int val2 = 6;
    printf("Deleting %d\n", val2);
    deleteNode(pSecond, val2);
    printf("Inorder traversal: \n");
    inorder(pSecond);
    printf("\n"); 
    printf("Total number of nodes in tree 1: %d", totalNodes(p));
    return 0;
}