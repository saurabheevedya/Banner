#include <stdio.h>
#include <stdlib.h>

#define size 7

struct node {
    int data;
    struct node * next;
};

struct node * chain[size];

void init(){
    for(int i=0; i<size; i++){
        chain[i] = NULL;
    }
}

void insert(int n){

    //create a newnode with value
    struct node * temp = (struct node *)malloc(sizeof(struct node));
    temp->data = n;
    temp->next = NULL;

    //calculate hash key
    int key = n%size;

    //check if chain[key] is empty
    
    if(chain[key] == NULL){
        chain[key] = temp;
    }
    //collision
    else{
        //add the node at the end of chain[key].
        struct node * temp2 = chain[key];
        while(temp2->next){
            temp2 = temp2->next;
        }
        temp2->next = temp;
    }
}

void printHashMap(){
    for(int i=0; i<size; i++){
        struct node * temp = chain[i];
        printf("Address %d: ", i);
        while(temp){
            printf("%d -> ", temp->data);
            temp = temp->next;
        }
        printf("NULL \n");
    }
}

int main(){
    init();

    insert(7);
    insert(0);
    insert(3);
    insert(10);
    insert(4);
    insert(5);

    printHashMap();
    printHashMap(); // if you use the same chain[i] for iteration, this next print will give all NULL values
                    // so, use temp nodes for iteration

    return 0;

}