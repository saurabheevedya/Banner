#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <cstring>

#define MAX_SIZE 100

int stack[MAX_SIZE];
int top = -1;

void push(int item) {
    if (top >= MAX_SIZE - 1) {
        printf("Stack Overflow\n");
        exit(1);
    }
    stack[++top] = item;
}

int pop() {
    if (top < 0) {
        printf("Stack Underflow\n");
        exit(1);
    }
    return stack[top--];
}

int evaluatePostfix(char *exp) {
    int i, op1, op2, result;
    for (i = 0; exp[i] != '\0'; i++) {
        if (isdigit(exp[i]))
            push(exp[i] - '0');
        else {
            op2 = pop();
            op1 = pop();
            switch (exp[i]) {
                case '+':
                    push(op1 + op2);
                    break;
                case '-':
                    push(op1 - op2);
                    break;
                case '*':
                    push(op1 * op2);
                    break;
                case '/':
                    push(op1 / op2);
                    break;
            }
        }
    }
    result = pop();
    return result;
}

int isOperator(char c) {
    if (c == '+' || c == '-' || c == '*' || c == '/')
        return 1;
    else
        return 0;
}

void convertPrefixToPostfix(char *prefix, char *postfix) {
    int i, j, k, len;
    char temp[MAX_SIZE];
    len = strlen(prefix);
    j = 0;
    for (i = len - 1; i >= 0; i--) {
        if (isOperator(prefix[i])) {
            postfix[j++] = temp[--k];
            postfix[j++] = temp[--k];
            postfix[j++] = prefix[i];
            temp[k++] = postfix[j - 3];
        } else {
            temp[k++] = prefix[i];
        }
    }
    postfix[j++] = temp[--k];
    postfix[j] = '\0';
}

int main() {
    char prefix[MAX_SIZE], postfix[MAX_SIZE];
    int result;

    printf("Enter a prefix expression: ");
    gets(prefix);

    convertPrefixToPostfix(prefix, postfix);
    printf("Postfix expression: %s\n", postfix);

    result = evaluatePostfix(postfix);
    printf("Result: %d\n", result);

    return 0;
}