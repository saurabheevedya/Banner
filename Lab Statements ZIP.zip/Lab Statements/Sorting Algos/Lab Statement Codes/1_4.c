#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_EMPLOYEES 100

typedef struct Employee {
    char employee_name[50];
    int emp_no;
    float emp_salary;
} Employee;

void shellSort(Employee arr[], int n, int *swap_count) {
    int gap, i, j;
    Employee temp;

    for (gap = n / 2; gap > 0; gap /= 2) {
        for (i = gap; i < n; i++) {
            temp = arr[i];
            for (j = i; j >= gap && arr[j - gap].emp_no > temp.emp_no; j -= gap) {
                arr[j] = arr[j - gap];
                (*swap_count)++;
            }
            arr[j] = temp;
        }
    }
}

void heapify(Employee arr[], int n, int i, int *swap_count) {
    int largest = i;
    int l = 2 * i + 1;
    int r = 2 * i + 2;
    Employee temp;

    if (l < n && arr[l].emp_no > arr[largest].emp_no) {
        largest = l;
    }

    if (r < n && arr[r].emp_no > arr[largest].emp_no) {
        largest = r;
    }

    if (largest != i) {
        temp = arr[i];
        arr[i] = arr[largest];
        arr[largest] = temp;
        (*swap_count)++;
        heapify(arr, n, largest, swap_count);
    }
}

void heapSort(Employee arr[], int n, int *swap_count) {
    int i;
    Employee temp;

    for (i = n / 2 - 1; i >= 0; i--) {
        heapify(arr, n, i, swap_count);
    }

    for (i = n - 1; i >= 0; i--) {
        temp = arr[i];
        arr[i] = arr[0];
        arr[0] = temp;
        (*swap_count)++;
        heapify(arr, i, 0, swap_count);
    }
}

int main() {
    int n, i, swap_count = 0;
    Employee arr[MAX_EMPLOYEES];

    printf("Enter the number of employees: ");
    scanf("%d", &n);

    printf("Enter employee details (name, emp_no, emp_salary):\n");
    for (i = 0; i < n; i++) {
        scanf("%s %d %f", &arr[i].employee_name, &arr[i].emp_no, &arr[i].emp_salary);
    }

    printf("\nBefore sorting:\n");
    printf("Employee Name\tEmployee No.\tEmployee Salary\n");
    for (i = 0; i < n; i++) {
        printf("%s\t\t%d\t\t%.2f\n", arr[i].employee_name, arr[i].emp_no, arr[i].emp_salary);
    }

    shellSort(arr, n, &swap_count);

    printf("\nAfter Shell sort:\n");
    printf("Employee Name\tEmployee No.\tEmployee Salary\n");
    for (i = 0; i < n; i++) {
        printf("%s\t\t%d\t\t%.2f\n", arr[i].employee_name, arr[i].emp_no, arr[i].emp_salary);
    }

    printf("\nNumber of swaps performed: %d\n", swap_count);

    swap_count = 0;

    heapSort(arr, n, &swap_count);

    printf("\nAfter Heap sort:\n");
    printf("Employee Name\tEmployee No.\tEmployee Salary\n");
    for (i = 0; i < n; i++) {
        printf("%s\t\t%d\t\t%.2f\n", arr[i].employee_name, arr[i].emp_no, arr[i].emp_salary);
    }

    printf("\nNumber of swaps performed: %d\n", swap_count);

    return 0;
}