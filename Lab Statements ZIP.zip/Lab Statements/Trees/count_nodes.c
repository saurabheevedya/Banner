#include <stdio.h>
#include <malloc.h>

struct Node{
    int data;
    struct Node * left;
    struct Node * right;
};

struct Node * createNode(int data){
    struct Node * p = (struct Node *)malloc(sizeof(struct Node)); // creating a node pointer and Allocating memory in the heap
    p->data = data; // Setting the data
    p->left = NULL; // Setting the left and right children to NULL
    p->right = NULL; 
    return p;
}

void preorder(struct Node * root){
    if(root!=NULL){
        printf("%d ", root->data);
        preorder(root->left);
        preorder(root->right);
    }
}

void postorder(struct Node * root){
    if(root!=NULL){
        postorder(root->left);
        postorder(root->right);
        printf("%d ", root->data);
    }
}

void inorder(struct Node * root){
    if(root!=NULL){
        inorder(root->left);
        printf("%d ", root->data);
        inorder(root->right);
    }
}

// count recursively:
int count(struct Node * root){
    if (root == NULL)
        return 0;

    int l = totalNodes(root->left);
    int r = totalNodes(root->right);
 
    return 1 + l + r;
}

struct Node * insert(struct Node * root, int key){
    struct Node * ptr = createNode(key); 
    if(root == NULL){
        root = ptr;
        root->left = NULL;
        root->right = NULL;
        return root;
    }
    struct Node * temp = root;
    while(temp != NULL){
        if(key < temp->data){
            if(temp->left == NULL){
                temp->left = ptr;
                return root;
            }
            else{
                temp = temp->left;
            }
        }
        else if(key > temp->data){
            if(temp->right == NULL){
                temp->right = ptr;
                return root;
            }
            else{
                temp = temp->right;
            }
        }
        else if(key == temp->data){
            printf("The record is already present in Tree \n");
            return root;
        }
    }
    
}

struct Node * inOrderPredecessor(struct Node * root){
    root = root->left;
    while(root->right != NULL){
        root = root->right;
    }
    return root;
}

struct Node * deleteNode(struct Node * root, int value){
    struct Node * iPre;
    // Returning if Leaf Node found, or NULL found
    if(root == NULL){
        printf("The data to delete is not found\n");
        return NULL;
    }
    // checking for leaf node, freeing it and returning NULL as its replacement
    if(root->left == NULL && root->right == NULL && value == root->data){ // additional 3rd condition for checking if the required node is present or not
        free(root);
        return NULL;
    }

    // Search for the node to be deleted
    if(value < root->data){
        root->left = deleteNode(root->left, value);
    }
    else if(value > root->data){
        root->right = deleteNode(root->right, value);
    }
    else if(value == root->data){
        // This else part of delete function will run only whenever there is a need to find inorder predecessor
        // As when the leaf Node is found
        // NULL is returned in that case in above part of code
        iPre = inOrderPredecessor(root);
        root->data = iPre->data;
        root->left = deleteNode(root->left, iPre->data);
    }
    return root;
}

int main(){
    struct Node * p = (struct Node *)malloc(sizeof(struct Node));
    p = NULL;
    p = insert(p, 10);
    p = insert(p, 5);
    p = insert(p, 15);
    p = insert(p, 3);
    p = insert(p, 9);
    p = insert(p, 17);
    p = insert(p, 1);
    p = insert(p, 4);
    // Finally The tree looks like this:
    //                10
    //               /  \
    //              5   15   
    //             / \     \
    //            3    9    17
    //           / \
    //          1   4

    struct Node * pSecond = (struct Node *)malloc(sizeof(struct Node));
    pSecond = NULL;
    pSecond = insert(pSecond, 10);
    pSecond = insert(pSecond, 6);
    pSecond = insert(pSecond, 15);
    pSecond = insert(pSecond, 4);
    pSecond = insert(pSecond, 9);
    pSecond = insert(pSecond, 17);
    pSecond = insert(pSecond, 2);
    pSecond = insert(pSecond, 1);
    pSecond = insert(pSecond, 3);
    // Finally The tree looks like this:
    //                10
    //               /  \
    //              6   15   
    //             / \     \
    //            4   9    17
    //           / 
    //          2
    //         / \
    //        1   3

    printf("Inorder traversal: \n");
    inorder(p);
    printf("\n");   

    // Checking Deletion:
    int val = 10;
    printf("Deleting %d\n", val);
    deleteNode(p, val);
    printf("Inorder traversal: \n");
    inorder(p);
    printf("\n");    


    printf("Inorder traversal: \n");
    inorder(pSecond);
    printf("\n"); 
    int val2 = 6;
    printf("Deleting %d\n", val2);
    deleteNode(pSecond, val2);
    printf("Inorder traversal: \n");
    inorder(pSecond);
    printf("\n"); 
    return 0;
} 