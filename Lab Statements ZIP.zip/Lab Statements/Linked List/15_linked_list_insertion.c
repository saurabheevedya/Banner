#include <stdio.h>
#include <stdlib.h>

struct Node{
    int data;
    struct Node * next;
};

void linkedlisttravesal(struct Node * ptr){
    while(ptr!=NULL){
        printf("Data: %d \n", ptr->data);
        ptr = ptr->next;
    }
}

// Case 1:
struct Node* inserAtFirst(struct Node * head, int data){
    struct Node * ptr = (struct Node *)malloc(sizeof(struct Node));
    ptr->next = head;
    ptr->data = data;
    return ptr;
}

// Case 2:
struct Node * insertAtIndex(struct Node* head, int data, int index){
    struct Node * ptr = (struct Node *)malloc(sizeof(struct Node));
    struct Node * p = head;
    for(int i = 1; i<index-1; i++){
        p = p->next;
    }
    ptr->next = p->next;
    p->next = ptr;
    ptr->data = data;
    return head;
}

// Case 3:
struct Node* insertAtEnd(struct Node * head, int data){
    struct Node * ptr = (struct Node *)malloc(sizeof(struct Node));
    struct Node * p = head;
    for(int i = 1; p->next != NULL; i++){
        p = p->next;
    }
    p->next = ptr;
    ptr->next = NULL;
    ptr->data = data;
    return head;
}

// Case 4:
void insertAfterNode(struct Node * prevNode, int data){
    struct Node * ptr = (struct Node *)malloc(sizeof(struct Node));
    ptr->next = prevNode->next;
    prevNode->next = ptr;
    ptr->data = data;
}
// OR
struct Node* insertAfterNode2(struct Node * head, struct Node * prevNode, int data){
    struct Node * ptr = (struct Node *)malloc(sizeof(struct Node));
    ptr->next = prevNode->next;
    prevNode->next = ptr;
    ptr->data = data;
    return head;
}

int main(){
    struct Node * head;
    struct Node * second;
    struct Node * third;
    struct Node * fourth;

    head = (struct Node *)malloc(sizeof(struct Node));
    second = (struct Node *)malloc(sizeof(struct Node));
    third = (struct Node *)malloc(sizeof(struct Node));
    fourth = (struct Node *)malloc(sizeof(struct Node));

    head->data = 12;
    head->next = second;

    second->data = 22;
    second->next = third;

    third->data = 32;
    third->next = fourth;

    fourth->data = 42;
    fourth->next = NULL;

    printf("Before Insertion:\n");
    linkedlisttravesal(head);
    printf("\n");

    head = inserAtFirst(head, 44);
    linkedlisttravesal(head);
    printf("\n");

    head = insertAtIndex(head, 45, 3);
    linkedlisttravesal(head);
    printf("\n");

    head = insertAtEnd(head, 46);
    linkedlisttravesal(head);
    printf("\n");
    
    insertAfterNode(second, 47);
    linkedlisttravesal(head);
    printf("\n");

}
