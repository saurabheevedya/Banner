#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int main(){
    char * arr = "dtsvs";
    int n = strlen(arr);
    char ch = 'O';
    char * arr2 = (char *)malloc((n + 2)* sizeof(char));

    strcpy(arr2, arr);
    arr2[n] = ch;
    arr2[n+1] = '\0';
    
    char * constr = "Harsh)";
    strcat(arr2, constr);
    
    // char * close = ")";
    // strcat(arr2, close);
    // printf("%c \n", arr[2]);
    // arr[n] = ch;
    // n++;
    // printf("heyy\n");
    // arr[n] = '\0';

    // strncat(arr, &ch, 1);
    // char * arr3 = strcat(arr, arr2);
    printf("%s %d", arr2, n);
}

